-- Thrivar Phase 1 schema: the profiles table only.
-- Run this once in your Supabase project's SQL Editor.
-- (Assessments, plans, journal, and coach tables are added in later phases.)

create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  season text,
  season_line text,
  scores jsonb,
  strengths jsonb,
  growth jsonb,
  priority text,
  completed_at timestamptz default now(),
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;

create policy "Users can view their own profiles"
  on public.profiles for select
  using (auth.uid() = user_id);

create policy "Users can insert their own profiles"
  on public.profiles for insert
  with check (auth.uid() = user_id);

create policy "Users can update their own profiles"
  on public.profiles for update
  using (auth.uid() = user_id);
