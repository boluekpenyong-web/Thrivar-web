import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import LogoutButton from "./LogoutButton";

export default async function DashboardPage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  return (
    <main className="min-h-screen px-6 py-10 bg-cream">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-10">
          <div>
            <p className="text-sm text-ink/50">Signed in as</p>
            <p className="text-ink">{user.email}</p>
          </div>
          <LogoutButton />
        </div>
        <h1 className="text-3xl font-display mb-4 text-cobalt">
          Welcome to Thrivar
        </h1>
        <p className="text-ink/70 leading-relaxed">
          Your account is set up and this page is protected - only a logged-in
          user can see it. The Transformation Assessment, your profile, and
          your plan will appear here in Phase 2.
        </p>
      </div>
    </main>
  );
}
