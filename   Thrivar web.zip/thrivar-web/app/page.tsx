import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col bg-cream">
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-20 text-center">
        <div className="w-20 h-20 rounded-full flex items-center justify-center mb-8 bg-cobalt">
          <span className="text-3xl font-display text-cream">T</span>
        </div>
        <h1 className="text-5xl md:text-6xl font-display mb-4 text-cobalt">
          Thrivar
        </h1>
        <p className="text-xl italic font-display mb-8 text-ink">
          A transformation operating system.
        </p>
        <p className="max-w-md text-base leading-relaxed mb-10 text-ink/70">
          Not a chatbot. Not a checklist. A structured place to understand
          where you are, what&apos;s keeping you there, and how to move
          toward who you&apos;re becoming.
        </p>
        <div className="flex gap-4">
          <Link
            href="/signup"
            className="px-8 py-4 rounded-full text-base bg-cobalt text-cream"
          >
            Let&apos;s begin
          </Link>
          <Link
            href="/login"
            className="px-8 py-4 rounded-full text-base border border-cobalt text-cobalt"
          >
            Log in
          </Link>
        </div>
      </div>

      <div className="px-8 py-14 bg-cobalt">
        <div className="max-w-sm mx-auto divide-y divide-white/20">
          {[
            "Six dimensions. One honest picture of where you are.",
            "A pathway built around what you actually need.",
            "A coach that already knows your story.",
          ].map((line) => (
            <p
              key={line}
              className="py-5 text-lg text-center italic font-display text-cream"
            >
              {line}
            </p>
          ))}
        </div>
      </div>
    </main>
  );
}
