# Thrivar — Phase 1

A real Next.js + Supabase web app: public landing page, working sign-up/login,
and a protected dashboard. No AI or assessment yet - that's Phase 2 and 3.

## What's in this project

- `/` - public landing page
- `/signup`, `/login` - real authentication via Supabase
- `/dashboard` - protected route; redirects to /login if not signed in
- `middleware.ts` - enforces that protection
- `supabase/schema.sql` - the one database table this phase needs

## Setup (do this once)

### 1. Create your Supabase project
Go to supabase.com, sign in with your own account, and create a new project.
Wait for it to finish provisioning (a couple of minutes).

### 2. Run the schema
In your Supabase project, open the **SQL Editor**, paste in the contents of
`supabase/schema.sql`, and run it. This creates the `profiles` table.

### 3. Get your project keys
In Supabase, go to **Project Settings → API**. Copy:
- Project URL
- `anon` `public` key

These are safe to use in a browser - they are not secrets like your account
password.

### 4. Configure environment variables locally
Copy `.env.local.example` to `.env.local` and fill in the two values from
step 3:

```
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
```

### 5. Install and run locally
```
npm install
npm run dev
```
Visit http://localhost:3000 - you should see the landing page, and be able
to sign up, confirm your email, log in, and see the dashboard.

### 6. Deploy to Vercel
- Push this project to a GitHub repository
- Go to vercel.com, sign in with your own account, and import that repo
- When prompted for environment variables, add the same two from step 3
- Deploy

### 7. Point Supabase at your real deployment
In Supabase, go to **Authentication → URL Configuration** and set:
- **Site URL**: your Vercel deployment URL (e.g. `https://thrivar.vercel.app`)
- **Redirect URLs**: add `https://thrivar.vercel.app/auth/callback`

Without this step, email confirmation links will redirect to localhost
instead of your live site.

### Optional: skip email confirmation while testing
In Supabase, go to **Authentication → Providers → Email** and turn off
"Confirm email" if you want to sign up and log in immediately without
checking your inbox each time. Turn it back on before real users sign up.

## What's next

- **Phase 2**: the Transformation Assessment, profile computation, season
  reveal, Transformation Map, and Plan - all saved to the `profiles` table
  and tied to the logged-in user.
- **Phase 3**: the Coach, with the AI call happening server-side (so the
  API key is never exposed), full context assembly, and the four voices.
